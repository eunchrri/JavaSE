package datastructure;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import chapter06.Employee;

public class SortTest {
	public static void main(String[] args) {

		System.out.println("=================================");
		ArrayList<Employee> list = new ArrayList<Employee>(5);
		list.add(new Employee("1", "ssafy3", 3500000));
		list.add(new Employee("5", "ssafy2", 2500000));
		list.add(new Employee("2", "ssafy4", 1500000));
		list.add(new Employee("4", "ssafy5", 3000000));
		list.add(new Employee("3", "ssafy1", 4500000));

	}
}
